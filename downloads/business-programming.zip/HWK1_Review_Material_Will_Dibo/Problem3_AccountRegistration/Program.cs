Console.WriteLine("ACCOUNT REGISTRATION");
Console.WriteLine(new string('=', 45));

string firstName = ReadInput("First name: ").Trim();
string lastName = ReadInput("Last name: ").Trim();
string email = ReadInput("Email address: ").Trim();
Console.WriteLine("Password requirements: 8+ characters, an uppercase letter, and a number.");
string password = ReadInput("Password: ");
string confirmPassword = ReadInput("Confirm password: ");
string ageInput = ReadInput("Age: ");

List<string> validationProblems = ValidateRegistration(firstName, lastName, email,
    password, confirmPassword, ageInput);
DisplayRegistrationResult(validationProblems, firstName, lastName);

string ReadInput(string prompt)
{
    Console.Write(prompt);
    return Console.ReadLine() ?? string.Empty;
}

bool IsValidEmail(string email)
{
    // These are the three email checks specified in the assignment.
    return email.Length >= 6 && email.Contains('@') && email.Contains('.');
}

bool IsValidPassword(string password)
{
    return password.Length >= 8 && HasUppercaseLetter(password) && HasNumber(password);
}

bool HasUppercaseLetter(string password)
{
    foreach (char character in password)
    {
        if (char.IsUpper(character)) return true;
    }
    return false;
}

bool HasNumber(string password)
{
    foreach (char character in password)
    {
        if (char.IsDigit(character)) return true;
    }
    return false;
}

bool IsValidAge(int age)
{
    return age >= 18;
}

List<string> ValidateRegistration(string firstName, string lastName, string email,
    string password, string confirmPassword, string ageInput)
{
    List<string> problems = new List<string>();

    // Use independent checks so every validation problem appears together.
    if (string.IsNullOrWhiteSpace(firstName))
    {
        problems.Add("First name cannot be blank.");
    }

    if (string.IsNullOrWhiteSpace(lastName))
    {
        problems.Add("Last name cannot be blank.");
    }

    if (!IsValidEmail(email))
    {
        if (!email.Contains('@'))
        {
            problems.Add("Email address must contain an @ symbol.");
        }
        if (!email.Contains('.'))
        {
            problems.Add("Email address must contain a period (.).");
        }
        if (email.Length < 6)
        {
            problems.Add("Email address must be at least 6 characters long.");
        }
    }

    if (!IsValidPassword(password))
    {
        if (password.Length < 8)
        {
            problems.Add("Password must be at least 8 characters long.");
        }
        if (!HasUppercaseLetter(password))
        {
            problems.Add("Password must contain an uppercase letter.");
        }
        if (!HasNumber(password))
        {
            problems.Add("Password must contain at least one number.");
        }
    }

    // Do not trim passwords: capitalization and spaces must match exactly.
    if (password != confirmPassword)
    {
        problems.Add("Passwords do not match.");
    }

    if (!int.TryParse(ageInput, out int age))
    {
        problems.Add("Age must be a whole number.");
    }
    else if (!IsValidAge(age))
    {
        problems.Add("You must be at least 18 years old.");
    }

    return problems;
}

void DisplayRegistrationResult(List<string> problems, string firstName, string lastName)
{
    Console.WriteLine();

    if (problems.Count > 0)
    {
        Console.WriteLine("Registration Failed");
        Console.WriteLine();
        foreach (string problem in problems)
        {
            Console.WriteLine($"- {problem}");
        }
    }
    else
    {
        Console.WriteLine("Account Successfully Created!");
        Console.WriteLine();
        Console.WriteLine($"Welcome, {firstName} {lastName}!");
    }
}
