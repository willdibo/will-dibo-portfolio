# HWK 1 - Review Material

Will Dibo

This Visual Studio solution contains four separate C# console applications.
It targets .NET 10, matching the uploaded class review projects. The source
uses the same basic approach as those examples: top-level statements,
functions, loops, collections, and simple classes.

## Open and run

1. Extract the entire ZIP before opening the solution.
2. Open `HWK1_Review_Material.sln` in Visual Studio with the .NET 10 SDK installed.
3. In Solution Explorer, right-click the project you want to run and select
   **Set as Startup Project**.
4. Press **Ctrl+F5** to run it and keep the console visible afterward.
5. Repeat steps 3-4 for the other projects.

All four projects are part of the same solution. No additional NuGet packages
or input files are needed.

| Project | Assignment problem |
| --- | --- |
| Problem1_ShippingCalculator | Shipping Calculator |
| Problem2_RestaurantOrder | Restaurant Order |
| Problem3_AccountRegistration | Account Registration Validator |
| Problem4_ProductSearch | Product Search & Filter |

## Program notes

### 1. Shipping Calculator

- Enter the subtotal, rewards status (`Y` or `N`), and shipping method (`1`-`3`).
- Invalid inputs are rejected and requested again.
- Standard shipping costs $5.99, or $0 for a subtotal of at least $75.
- Two-Day costs $12.99; Overnight costs $24.99. Rewards members save 20% on
  those two methods. Rewards status does not change Standard shipping.
- `CalculateShipping(subtotal, method, rewardsStatus)` returns the shipping
  charge. It also rejects nonpositive subtotals and invalid methods if called
  directly.
- Enter dollar amounts with a decimal point, without a dollar sign or commas.
  Entered subtotals and shipping charges are rounded to cents.

### 2. Restaurant Order

- Select items `1`-`5` as many times as needed; enter `0` to finish.
- The order is a `List<MenuItem>`. Each valid selection adds one item, including
  repeated selections. Invalid selections do not add anything.
- Separate functions display the menu, add an item, calculate the subtotal,
  and calculate the final total.
- A subtotal of at least $30 receives a 10% discount. Sales tax is 8.5% of the
  amount after the discount. The discount and tax are rounded to cents before
  computing the final total, so the receipt amounts reconcile.
- `CalculateFinalTotal` returns the total and uses `out` parameters to provide
  the discount and tax for the receipt.
- Finishing an empty order displays no items and $0.00 totals.

### 3. Account Registration Validator

- Enter all six requested fields. The program then lists every failed rule
  together, including each missing email and password requirement.
- `IsValidEmail`, `IsValidPassword`, and `IsValidAge` each return a Boolean.
- Email validation follows the assignment's three rules: at least six
  characters, an `@`, and a period. Passwords need at least eight characters,
  an uppercase letter, and a number.
- Names cannot be blank; passwords must match exactly; age must be a whole
  number of at least 18.
- Leading and trailing spaces are removed from names and email. Passwords are
  compared exactly as entered, including capitalization and spaces.
- Successful validation displays the required welcome message. This is a
  console validation exercise; it does not store account information.

### 4. Product Search & Filter

- Choose menu options `1`-`6`. Option `6` exits.
- The catalog contains 12 products across Electronics, Furniture, Clothing,
  and Home. Each `Product` has `Name`, `Category`, `Price`, and `InStock`.
- Name searches accept a full or partial name. Name and category comparisons
  ignore capitalization; category matching uses the full category name.
- Maximum-price filtering includes products priced exactly at the maximum.
- Each operation searches the complete catalog independently. All matches are
  displayed, or a clear message appears when no products match.

## Build from a terminal

Run these commands from the folder containing the solution:

```text
dotnet build HWK1_Review_Material.sln
dotnet run --project Problem1_ShippingCalculator
dotnet run --project Problem2_RestaurantOrder
dotnet run --project Problem3_AccountRegistration
dotnet run --project Problem4_ProductSearch
```

## Submission

Upload the complete `HWK1_Review_Material_Will_Dibo.zip` to the assignment.
The ZIP contains the solution file, all four project folders, and this guide.
The `bin`, `obj`, and Visual Studio user settings folders are intentionally
excluded; Visual Studio recreates them when building.

## Verification

The complete solution built successfully in Release configuration with the
.NET 10 SDK, with zero warnings and zero errors. Scripted console checks
passed for all 52 scenarios:

| Project | Passed scenarios | Examples checked |
| --- | ---: | --- |
| Shipping Calculator | 15 | All shipping rates; rewards discounts; $74.99/$75/$75.01 thresholds; invalid input |
| Restaurant Order | 8 | Empty order; all five menu items; repeated items; discounts and tax; invalid selections |
| Account Registration | 15 | Successful registration; age 18; each individual validation rule; all 10 errors together |
| Product Search & Filter | 14 | All products; partial name search; categories; inclusive price limit; stock; no matches; invalid input |

These checks also confirmed that the applications exit without hanging when
console input is closed.
