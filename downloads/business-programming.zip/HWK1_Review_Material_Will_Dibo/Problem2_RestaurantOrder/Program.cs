using System.Globalization;
using Problem2_RestaurantOrder;

CultureInfo.CurrentCulture = CultureInfo.GetCultureInfo("en-US");

List<MenuItem> menu = CreateMenu();
List<MenuItem> order = new List<MenuItem>();

Console.WriteLine("RESTAURANT ORDER");
Console.WriteLine(new string('=', 45));
TakeOrder(menu, order);
DisplayOrderSummary(order);

List<MenuItem> CreateMenu()
{
    return new List<MenuItem>
    {
        new MenuItem { Name = "Burger", Price = 10.99m },
        new MenuItem { Name = "Chicken Sandwich", Price = 9.99m },
        new MenuItem { Name = "Salad", Price = 8.49m },
        new MenuItem { Name = "Fries", Price = 3.49m },
        new MenuItem { Name = "Drink", Price = 2.49m }
    };
}

void DisplayMenu(List<MenuItem> menu)
{
    Console.WriteLine();
    Console.WriteLine("MENU");
    for (int index = 0; index < menu.Count; index++)
    {
        Console.WriteLine($"{index + 1} - {menu[index].Name,-20} {menu[index].Price,8:C2}");
    }
    Console.WriteLine("0 - Finish ordering");
    Console.WriteLine("Orders of $30 or more receive a 10% discount.");
}

void TakeOrder(List<MenuItem> menu, List<MenuItem> order)
{
    while (true)
    {
        DisplayMenu(menu);
        Console.Write("Choose an item (0-5): ");
        string? input = Console.ReadLine();
        if (input == null) return;

        if (!int.TryParse(input, out int selection))
        {
            Console.WriteLine("Invalid selection. Enter a number from 0 to 5.");
            continue;
        }

        if (selection == 0) return;

        if (AddItemToOrder(menu, order, selection))
        {
            Console.WriteLine($"Added: {menu[selection - 1].Name}");
        }
        else
        {
            Console.WriteLine("Invalid selection. Enter a number from 0 to 5.");
        }
    }
}

bool AddItemToOrder(List<MenuItem> menu, List<MenuItem> order, int selection)
{
    if (selection < 1 || selection > menu.Count)
    {
        return false;
    }

    // Menu choices start at 1; collection indexes start at 0.
    // Each selection is stored, including repeated selections of the same item.
    order.Add(menu[selection - 1]);
    return true;
}

decimal CalculateSubtotal(List<MenuItem> order)
{
    decimal subtotal = 0m;
    foreach (MenuItem item in order)
    {
        subtotal += item.Price;
    }
    return subtotal;
}

decimal CalculateFinalTotal(decimal subtotal, out decimal discount, out decimal tax)
{
    discount = 0m;
    if (subtotal >= 30m)
    {
        discount = Math.Round(subtotal * 0.10m, 2, MidpointRounding.AwayFromZero);
    }

    // Apply sales tax after the discount. Round each receipt amount to cents
    // so the displayed subtotal, discount, and tax add up to the final total.
    decimal discountedSubtotal = subtotal - discount;
    tax = Math.Round(discountedSubtotal * 0.085m, 2, MidpointRounding.AwayFromZero);

    return discountedSubtotal + tax;
}

void DisplayOrderSummary(List<MenuItem> order)
{
    Console.WriteLine();
    Console.WriteLine("ORDER SUMMARY");
    Console.WriteLine(new string('-', 45));

    if (order.Count == 0)
    {
        Console.WriteLine("No items ordered.");
    }
    else
    {
        for (int index = 0; index < order.Count; index++)
        {
            Console.WriteLine($"{index + 1,2}. {order[index].Name,-22} {order[index].Price,8:C2}");
        }
    }

    decimal subtotal = CalculateSubtotal(order);
    decimal finalTotal = CalculateFinalTotal(subtotal, out decimal discount, out decimal tax);

    Console.WriteLine(new string('-', 45));
    Console.WriteLine($"Subtotal:       {subtotal,10:C2}");
    Console.WriteLine($"Discount (10%): {discount,10:C2}");
    Console.WriteLine($"Tax (8.5%):     {tax,10:C2}");
    Console.WriteLine($"Final total:    {finalTotal,10:C2}");
}
