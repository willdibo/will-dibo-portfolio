namespace Problem2_RestaurantOrder;

public class MenuItem
{
    public string Name { get; set; } = string.Empty;
    public decimal Price { get; set; }
}
