using System.Globalization;

// Display dollar amounts consistently, regardless of the computer's region.
CultureInfo.CurrentCulture = CultureInfo.GetCultureInfo("en-US");

Console.WriteLine("SHIPPING CALCULATOR");
Console.WriteLine(new string('=', 45));

decimal? orderSubtotal = ReadOrderSubtotal();
if (orderSubtotal == null) return;

bool? isRewardsMember = ReadRewardsStatus();
if (isRewardsMember == null) return;

int? shippingMethod = ReadShippingMethod();
if (shippingMethod == null) return;

decimal shippingCost = CalculateShipping(orderSubtotal.Value, shippingMethod.Value,
    isRewardsMember.Value);
DisplayOrderSummary(orderSubtotal.Value, shippingMethod.Value, shippingCost);

decimal? ReadOrderSubtotal()
{
    while (true)
    {
        Console.Write("Order subtotal (example: 49.99): ");
        string? input = Console.ReadLine();
        if (input == null) return null;

        if (decimal.TryParse(input.Trim(), NumberStyles.AllowDecimalPoint |
            NumberStyles.AllowLeadingSign, CultureInfo.CurrentCulture, out decimal subtotal))
        {
            // Round entered money to cents before using it in calculations.
            subtotal = Math.Round(subtotal, 2, MidpointRounding.AwayFromZero);

            // Reserve enough room for shipping so adding it cannot overflow.
            if (subtotal > 0 && subtotal <= decimal.MaxValue - 24.99m)
            {
                return subtotal;
            }
        }

        Console.WriteLine("Invalid subtotal. Enter a dollar amount greater than $0 within the supported numeric range.");
    }
}

bool? ReadRewardsStatus()
{
    while (true)
    {
        Console.Write("Are you a rewards member? (Y/N): ");
        string? input = Console.ReadLine();
        if (input == null) return null;

        input = input.Trim().ToUpperInvariant();
        if (input == "Y") return true;
        if (input == "N") return false;

        Console.WriteLine("Invalid rewards status. Enter Y or N.");
    }
}

int? ReadShippingMethod()
{
    Console.WriteLine();
    Console.WriteLine("1 - Standard  ($5.99; free for orders of $75 or more)");
    Console.WriteLine("2 - Two-Day   ($12.99)");
    Console.WriteLine("3 - Overnight ($24.99)");
    Console.WriteLine("Rewards members save 20% on Two-Day and Overnight shipping.");

    while (true)
    {
        Console.Write("Choose a shipping method (1-3): ");
        string? input = Console.ReadLine();
        if (input == null) return null;

        if (int.TryParse(input, out int method) && method >= 1 && method <= 3)
        {
            return method;
        }

        Console.WriteLine("Invalid shipping method. Enter 1, 2, or 3.");
    }
}

decimal CalculateShipping(decimal orderSubtotal, int shippingMethod, bool isRewardsMember)
{
    // Protect the calculation even if this function is called without the input prompts.
    if (orderSubtotal <= 0)
    {
        throw new ArgumentOutOfRangeException(nameof(orderSubtotal),
            "The order subtotal must be greater than zero.");
    }

    decimal shippingCost;

    switch (shippingMethod)
    {
        case 1:
            shippingCost = orderSubtotal >= 75m ? 0m : 5.99m;
            break;
        case 2:
            shippingCost = 12.99m;
            break;
        case 3:
            shippingCost = 24.99m;
            break;
        default:
            throw new ArgumentOutOfRangeException(nameof(shippingMethod),
                "The shipping method must be 1, 2, or 3.");
    }

    if (isRewardsMember && (shippingMethod == 2 || shippingMethod == 3))
    {
        shippingCost *= 0.80m;
    }

    return Math.Round(shippingCost, 2, MidpointRounding.AwayFromZero);
}

string GetShippingMethodName(int shippingMethod)
{
    switch (shippingMethod)
    {
        case 1: return "Standard";
        case 2: return "Two-Day";
        case 3: return "Overnight";
        default: return "Unknown";
    }
}

void DisplayOrderSummary(decimal subtotal, int method, decimal shippingCost)
{
    decimal finalTotal = subtotal + shippingCost;

    Console.WriteLine();
    Console.WriteLine("ORDER SUMMARY");
    Console.WriteLine(new string('-', 45));
    Console.WriteLine($"Order subtotal:   {subtotal:C2}");
    Console.WriteLine($"Shipping method:  {GetShippingMethodName(method)}");
    Console.WriteLine($"Shipping cost:    {shippingCost:C2}");
    Console.WriteLine($"Final order total: {finalTotal:C2}");
}
