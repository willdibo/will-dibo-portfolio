using System.Globalization;
using Problem4_ProductSearch;

CultureInfo.CurrentCulture = CultureInfo.GetCultureInfo("en-US");

List<Product> products = CreateProducts();
RunProductMenu(products);

List<Product> CreateProducts()
{
    return new List<Product>
    {
        new Product { Name = "Laptop", Category = "Electronics", Price = 999.99m, InStock = true },
        new Product { Name = "Smartphone", Category = "Electronics", Price = 799.99m, InStock = false },
        new Product { Name = "Headphones", Category = "Electronics", Price = 99.99m, InStock = true },
        new Product { Name = "Monitor", Category = "Electronics", Price = 299.99m, InStock = true },
        new Product { Name = "Keyboard", Category = "Electronics", Price = 49.99m, InStock = false },
        new Product { Name = "Desk Chair", Category = "Furniture", Price = 149.99m, InStock = true },
        new Product { Name = "Coffee Table", Category = "Furniture", Price = 199.99m, InStock = false },
        new Product { Name = "Bookshelf", Category = "Furniture", Price = 89.99m, InStock = true },
        new Product { Name = "T-Shirt", Category = "Clothing", Price = 19.99m, InStock = true },
        new Product { Name = "Hoodie", Category = "Clothing", Price = 39.99m, InStock = false },
        new Product { Name = "Coffee Mug", Category = "Home", Price = 9.99m, InStock = true },
        new Product { Name = "Blanket", Category = "Home", Price = 24.99m, InStock = true }
    };
}

void DisplayMenu()
{
    Console.WriteLine();
    Console.WriteLine("PRODUCT SEARCH & FILTER");
    Console.WriteLine(new string('=', 65));
    Console.WriteLine("1 - View all products");
    Console.WriteLine("2 - Search products by name");
    Console.WriteLine("3 - Filter products by category");
    Console.WriteLine("4 - Filter products by maximum price");
    Console.WriteLine("5 - Show only products currently in stock");
    Console.WriteLine("6 - Exit");
}

void RunProductMenu(List<Product> products)
{
    while (true)
    {
        DisplayMenu();
        Console.Write("Choose an option (1-6): ");
        string? input = Console.ReadLine();
        if (input == null) return;

        if (!int.TryParse(input, out int selection))
        {
            Console.WriteLine("Invalid option. Enter a number from 1 to 6.");
            continue;
        }

        switch (selection)
        {
            case 1:
                DisplayProducts(products);
                break;
            case 2:
                string? searchTerm = ReadRequiredText("Enter all or part of a product name: ");
                if (searchTerm == null) return;
                DisplayProducts(SearchProducts(products, searchTerm));
                break;
            case 3:
                Console.WriteLine("Categories: Electronics, Furniture, Clothing, Home");
                string? category = ReadRequiredText("Enter a category: ");
                if (category == null) return;
                DisplayProducts(FilterByCategory(products, category));
                break;
            case 4:
                decimal? maximumPrice = ReadMaximumPrice();
                if (maximumPrice == null) return;
                DisplayProducts(FilterByPrice(products, maximumPrice.Value));
                break;
            case 5:
                DisplayProducts(FilterInStock(products));
                break;
            case 6:
                Console.WriteLine("Thank you for browsing. Goodbye!");
                return;
            default:
                Console.WriteLine("Invalid option. Enter a number from 1 to 6.");
                break;
        }
    }
}

string? ReadRequiredText(string prompt)
{
    while (true)
    {
        Console.Write(prompt);
        string? input = Console.ReadLine();
        if (input == null) return null;

        input = input.Trim();
        if (!string.IsNullOrWhiteSpace(input)) return input;

        Console.WriteLine("Please enter a nonblank value.");
    }
}

decimal? ReadMaximumPrice()
{
    while (true)
    {
        Console.Write("Enter the maximum price (example: 50.00): ");
        string? input = Console.ReadLine();
        if (input == null) return null;

        if (decimal.TryParse(input.Trim(), NumberStyles.AllowDecimalPoint |
            NumberStyles.AllowLeadingSign, CultureInfo.CurrentCulture,
            out decimal maximumPrice) && maximumPrice >= 0)
        {
            return maximumPrice;
        }

        Console.WriteLine("Invalid price. Enter a number greater than or equal to zero.");
    }
}

void DisplayProducts(List<Product> products)
{
    Console.WriteLine();
    if (products.Count == 0)
    {
        Console.WriteLine("No products match your criteria.");
        return;
    }

    Console.WriteLine($"{"Product Name",-24} {"Category",-14} {"Price",10} {"In Stock",-12}");
    Console.WriteLine(new string('-', 65));
    foreach (Product product in products)
    {
        string stockStatus = product.InStock ? "Yes" : "No";
        Console.WriteLine($"{product.Name,-24} {product.Category,-14} {product.Price,10:C2} {stockStatus,-12}");
    }
    Console.WriteLine($"Products found: {products.Count}");
}

List<Product> SearchProducts(List<Product> products, string searchTerm)
{
    List<Product> matches = new List<Product>();
    foreach (Product product in products)
    {
        if (product.Name.Contains(searchTerm, StringComparison.OrdinalIgnoreCase))
        {
            matches.Add(product);
        }
    }
    return matches;
}

List<Product> FilterByCategory(List<Product> products, string category)
{
    List<Product> matches = new List<Product>();
    foreach (Product product in products)
    {
        if (product.Category.Equals(category, StringComparison.OrdinalIgnoreCase))
        {
            matches.Add(product);
        }
    }
    return matches;
}

List<Product> FilterByPrice(List<Product> products, decimal maximumPrice)
{
    List<Product> matches = new List<Product>();
    foreach (Product product in products)
    {
        // Include products priced exactly at the customer's maximum.
        if (product.Price <= maximumPrice)
        {
            matches.Add(product);
        }
    }
    return matches;
}

List<Product> FilterInStock(List<Product> products)
{
    List<Product> matches = new List<Product>();
    foreach (Product product in products)
    {
        if (product.InStock)
        {
            matches.Add(product);
        }
    }
    return matches;
}
